ULTRAS GREEN GHOST — GitHub Actions APK builder

Repository contents required:
1) ULTRAS-GREEN-GHOST-EXPO.zip (at repository root)
2) .github/workflows/build-apk.yml (exact path)

Before running:
- Create an Expo access token at https://expo.dev/accounts/[your-account]/settings/access-tokens
- In GitHub repository: Settings > Secrets and variables > Actions > New repository secret
- Name: EXPO_TOKEN
- Value: paste the Expo access token

Run:
- GitHub repository > Actions
- Select "Build ULTRAS GREEN GHOST APK"
- Tap "Run workflow"
- Wait for the job to finish. EAS Build prints the APK download link in the logs.

The workflow uses Expo EAS cloud build. EXPO_TOKEN is required; never paste it into the workflow file or commit it to the repository.
